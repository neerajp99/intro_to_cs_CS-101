#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main() {
    char name[100];
    printf("Yeah, I woke up in the middle of the night \n For her I was feenin' \n So I had to take a little ride \n Backtrackin' on these few years \n Tryna figure out what I do to make it go bad \n 'Cause ever since my girl left me \n My whole life came crashin\', and I\'m so Lonely. \n LOL \n" );
    return 0;
}
