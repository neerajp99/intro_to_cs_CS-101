#include <stdio.h>
#include <stdlib.h>
#include<string.h>

int main() {
    char name[100];
    strcpy(name ,"Neeraj");
    printf("Hello, World. My name is %s! \n", name );
    return 0;
}
